__author__ = 'zhouyi1'
import urllib2,urllib, random
import qqUser,login,checkAuthCode
from PIL import Image
#'1' ment need authCode
if qqUser.checkAuthCode=='1':
    #https://ssl.captcha.qq.com/getimage?aid=1003903&r=0.2744625671611856&uin=2236678453&cap_cd=LTXa5y7uicPpkG_XJp11SMZCIi5hijbx
    datas = {'aid': qqUser.appid,
             'uin': qqUser.qq,
             'cap_cd': qqUser.cap_cd,
             'r':random.random()}
    url = 'https://ssl.captcha.qq.com/getimage?' + urllib.urlencode(datas)
    req = urllib2.Request(url)
    resp = urllib2.urlopen(req)
    fl = open('./authCodeImg/authCodeImage.jpg','wb')
    while 1:
        c = resp.read()
        if not c:
            break
        else:
            fl.write(c)
    fl.close()
    im = Image.open('./authCodeImg/authCodeImage.jpg')
    im.show()
    qqUser.authCode1 = raw_input('authCode:')
login.login()