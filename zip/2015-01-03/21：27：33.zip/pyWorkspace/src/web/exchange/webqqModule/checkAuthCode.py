__author__ = 'zhouyi1'
import urllib2,urllib, random,re,qqUser
param = {'pt_tea':'1',
        'uin': qqUser.qq,
        'js_ver': qqUser.js_ver,
        'js_type':'0',
        'login_sig': qqUser.loginSig,
        'u1':'http%3A%2F%2Fweb2.qq.com%2Floginproxy.html',
        'r':random.random()}
datas = urllib.urlencode(param)
#using GOT request method
url = 'https://ssl.ptlogin2.qq.com/check?'+datas
#print url
#req = urllib2.Request(url,datas)
req = urllib2.Request(url)
response = urllib2.urlopen(req)
html = response.read()
print html
autchCode = re.search(r"'(\d)','(.+)','(.+)'", html)
qqUser.checkAuthCode = autchCode.group(1)
print qqUser.checkAuthCode
qqUser.authCode1 = autchCode.group(2)
qqUser.authCode2 = autchCode.group(3)