__author__ = 'zhouyi1'
import urllib2,urllib,qqUser
from encryption import QQmd5
def login():
    url = 'https://ssl.ptlogin2.qq.com/login'
    datas = {'u':qqUser.qq,
             'p':str(QQmd5().md5_2(qqUser.pwd, qqUser.authCode1, qqUser.authCode2)),
             'verifycode':qqUser.authCode1,
             'webqq_type':10,
             'remember_uin':1,
             'login2qq':1,
             'aid':qqUser.appid,
             'u1':'http%3A%2F%2Fweb.qq.com%2Floginproxy.html%3Flogin2qq%3D1%26webqq_type%3D10',
             'h':1,
             'ptredirect':0,
             'ptlang':2052,
             'from_ui':1,
             'pttype':1,
             'dumy':'',
             'fp':'loginerroralert',
             'action':'3-14-15279',
             'mibao_css':'m_webqq',
             't':1,
             'g':1,
             'js_type':0,
             'js_ver':10015,
             'login_sig':'0ihp3t5ghfoonssle-98x9hy4uaqmpvu*8*odgl5vyerelcb8fk-y3ts6c3*7e8-'}
    params = urllib.urlencode(datas)
    req = urllib2.Request(url,params)
    resp = urllib2.urlopen(req)
    print resp.read()